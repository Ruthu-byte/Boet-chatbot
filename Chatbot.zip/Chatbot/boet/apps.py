from django.apps import AppConfig


class BoetConfig(AppConfig):
    name = 'boet'
